package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.Barrios;
import com.example.demo.models.Proveedores;
import com.example.demo.services.ProveedoresService;
import com.example.demo.services.BarriosService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/proveedores")
@AllArgsConstructor
public class ProveedoresController {
	
	@Autowired
	private ProveedoresService proveedoresService;
	
	@Autowired
	private BarriosService barriosService;
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("proveedores", proveedoresService.getAllProveedores());
		return "proveedores/listar";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		List<Barrios> barrios = barriosService.getAllBarrios();
		model.addAttribute("proveedor", new Proveedores());
		model.addAttribute("listadoBarrios", barrios);
		return "proveedores/formulario";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Proveedores proveedor) {
		proveedoresService.saveProveedor(proveedor);
		return "redirect:/proveedores";
	}
	
	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Proveedores> proveedor = proveedoresService.getProveedorById(id);

		if (proveedor.isPresent()) {
			List<Barrios> barrios = barriosService.getAllBarrios();
			model.addAttribute("proveedor", proveedor.get());
			model.addAttribute("listadoBarrios", barrios);
			return "proveedores/formulario";
		}

		return "redirect:/proveedores";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		proveedoresService.deleteProveedor(id);
		return "redirect:/proveedores";
	}
}

package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.Nacionalidades;
import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/nacionalidades")
@AllArgsConstructor
public class NacionalidadesController {

	//@Autowired
	//private NacionalidadesService nacionalidadesService;

	
	@GetMapping
	public String listar(Model model) {
		//model.addAttribute("nacionalidades", nacionalidadesService.getAllNacionalidades());
		return "empleados/listar";
	}

	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("nacionalidad", new Nacionalidades());
		return "empleados/formulario";
	}

	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Nacionalidades nacionalidad) {
		//nacionalidadesService.saveNacionalidad(nacionalidad);
		return "redirect:/empleados";
	}

	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {
		//Optional<Nacionalidades> nacionalidad = nacionalidadesService.getNacionalidadById(id);
		//if (nacionalidad.isPresent()) {
		//	model.addAttribute("nacionalidad", nacionalidad.get());
		//	return "empleados/formulario";
		//}
		return "redirect:/empleados";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		//nacionalidadesService.deleteNacionalidad(id);
		return "redirect:/empleados";
	}
}

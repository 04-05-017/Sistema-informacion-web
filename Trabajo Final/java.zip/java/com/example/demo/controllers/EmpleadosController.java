package com.example.demo.controllers;

import com.example.demo.models.Empleados;
import com.example.demo.models.Barrios;
import com.example.demo.models.EstadoCivil;
import com.example.demo.models.Nacionalidades;
import com.example.demo.models.Usuarios;
import com.example.demo.services.EmpleadosService;
import com.example.demo.services.BarriosService;
import com.example.demo.services.EstadoCivilService;
import com.example.demo.services.NacionalidadesService;
import com.example.demo.services.UsuariosService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping(value = "/empleados")
@AllArgsConstructor
public class EmpleadosController {

    @Autowired
    private EmpleadosService empleadosService;

    @Autowired
    private BarriosService barriosService;

    @Autowired
    private EstadoCivilService estadoCivilService;

    @Autowired
    private NacionalidadesService nacionalidadesService;

    @Autowired
    private UsuariosService usuariosService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("empleados", empleadosService.getAllEmpleados());
        return "empleados/listar";
    }

    @GetMapping("/form")
    public String mostrarFormulario(Model model) {
        model.addAttribute("empleado", new Empleados());
        cargarListas(model);
        return "empleados/formulario";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute Empleados empleado, BindingResult result, Model model) {
        if (result.hasErrors()) {
            cargarListas(model);
            return "empleados/formulario";
        }
        empleadosService.saveEmpleado(empleado);
        return "redirect:/empleados";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Optional<Empleados> empleado = empleadosService.getEmpleadoById(id);
        if (empleado.isPresent()) {
            model.addAttribute("empleado", empleado.get());
            cargarListas(model);
            return "empleados/formulario";
        }
        return "redirect:/empleados";
    }

    @PostMapping("/eliminar")
    public String eliminar(@RequestParam Long id) {
        empleadosService.deleteEmpleado(id);
        return "redirect:/empleados";
    }

    private void cargarListas(Model model) {
        List<Barrios> barrios = barriosService.getAllBarrios();
        List<EstadoCivil> estadosCiviles = estadoCivilService.getAllEstadosCiviles();
        List<Nacionalidades> nacionalidades = nacionalidadesService.getAllNacionalidades();
        List<Usuarios> usuarios = usuariosService.getAllUsuarios();
        model.addAttribute("listadoBarrios", barrios);
        model.addAttribute("listadoEstadosCiviles", estadosCiviles);
        model.addAttribute("listadoNacionalidades", nacionalidades);
        model.addAttribute("listadoUsuarios", usuarios);
    }
}

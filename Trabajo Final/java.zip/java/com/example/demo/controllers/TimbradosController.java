package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.models.Ciudades;
import com.example.demo.models.Timbrados;
import com.example.demo.models.TipoDocumentos;
import com.example.demo.services.TimbradosService;
import com.example.demo.services.TipoDocumentosService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/timbrados")
@AllArgsConstructor
public class TimbradosController {
	
	@Autowired
	private TimbradosService timbradosService;

	@Autowired
	private TipoDocumentosService tipoDocumentosService;
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("timbrados", timbradosService.getAllTimbrados());
		return "timbrados/listar";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		List<TipoDocumentos> tipoDocumentos = tipoDocumentosService.getAllTipoDocumentos();
		model.addAttribute("timbrado", new Timbrados());
		model.addAttribute("listadoTipoDocumentos", tipoDocumentos);
		return "timbrados/formulario";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Timbrados timbrado) {
		timbradosService.saveTimbrado(timbrado);
		return "redirect:/timbrados";
	}
	
	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Timbrados> timbrado = timbradosService.getTimbradoById(id);

		if (timbrado.isPresent()) {
			List<TipoDocumentos> tipoDocumentos = tipoDocumentosService.getAllTipoDocumentos();
			model.addAttribute("timbrado", timbrado.get());
			model.addAttribute("listadoTipoDocumentos", tipoDocumentos);
			return "timbrados/formulario";
		}
		return "redirect:/timbrados";
	}
	
	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		timbradosService.deleteTimbrado(id);
		return "redirect:/timbrados";
	}
}
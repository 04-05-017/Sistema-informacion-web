package com.example.demo.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.dto.Producto;
import com.example.demo.dto.Venta;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/ventas")
@AllArgsConstructor
public class VentasController {

	//-- Muestra el formulario para crear una nueva venta
    @GetMapping
    public String mostrarFormulario(Model model) {
        //-- Aquí puedes cargar datos de productos o clientes si es necesario
        return "ventas/formulario"; // Nombre del template Thymeleaf
    }

    // Recibe el formulario y guarda la venta
	//    @PostMapping
	//    public String registrarVenta(@RequestParam String fecha,
	//                                 @RequestParam String cliente,
	//                                 @RequestParam String tipoDocumento,
	//                                 @RequestParam String productosJson, // Productos enviados como JSON
	//                                 Model model) {
	//
	//        // Convertir el JSON de productos a una lista de Producto
	//        List<Producto> productos = convertirJsonAProductos(productosJson);
	//
	//        // Crear la venta (puedes guardarla en la base de datos si es necesario)
	//        Venta venta = new Venta();
	//        venta.setFecha(fecha);
	//        venta.setCliente(cliente);
	//        venta.setTipoDocumento(tipoDocumento);
	//        venta.setProductos(productos);
	//
	//        // Aquí podrías guardar la venta en la base de datos
	//
	//        model.addAttribute("venta", venta);
	//        model.addAttribute("mensaje", "Venta registrada con éxito");
	//        return "ventas/formulario"; // Mostrar el formulario nuevamente con la venta registrada
	//    }
	//
	//    // Método para convertir el JSON a una lista de productos (puedes usar una librería como Jackson)
	//    private List<Producto> convertirJsonAProductos(String productosJson) {
	//        // Convertir el JSON de productos a una lista de objetos Producto (puedes usar Jackson o Gson)
	//        // Por ejemplo con Jackson:
	//		//        ObjectMapper objectMapper = new ObjectMapper();
	//		//        try {
	//		//            return objectMapper.readValue(productosJson, new TypeReference<List<Producto>>(){});
	//		//        } catch (Exception e) {
	//		//            e.printStackTrace();
	//            return null;
	//            	//        }
	//    }
}

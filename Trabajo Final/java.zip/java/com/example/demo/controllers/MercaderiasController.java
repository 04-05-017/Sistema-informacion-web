package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.models.Marcas;
import com.example.demo.models.Procedencias;
import com.example.demo.models.TipoImpuesto;
import com.example.demo.models.Mercaderias;
import com.example.demo.services.TipoImpuestoService;
import com.example.demo.services.ProcedenciasService;
import com.example.demo.services.MarcasService;
import com.example.demo.services.MercaderiasService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/mercaderias")
@AllArgsConstructor
public class MercaderiasController {

	@Autowired
	private MercaderiasService mercaderiasService;
	
	@Autowired
	private MarcasService marcasService;
	
	@Autowired
	private ProcedenciasService procedenciasService;
	
	@Autowired
	private TipoImpuestoService tipoImpuestoService;
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("mercaderias", mercaderiasService.getAllMercaderias());
		return "mercaderias/listar";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		List<Marcas> marcas = marcasService.getAllMarcas();
		List<Procedencias> procedencias = procedenciasService.getAllProcedencias();
		List<TipoImpuesto> tipoImpuesto = tipoImpuestoService.getAllTipoImpuesto();
		model.addAttribute("mercaderia", new Mercaderias());
		model.addAttribute("listadoMarcas", marcas);
		model.addAttribute("listadoProcedencias", procedencias);
		model.addAttribute("listadoTipoImpuesto", tipoImpuesto);
		return "mercaderias/formulario";
	}

	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Mercaderias mercaderia) {
		mercaderiasService.saveMercaderia(mercaderia);
		return "redirect:/mercaderias";
	}

	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Mercaderias> mercaderia = mercaderiasService.getMercaderiaById(id);

		if (mercaderia.isPresent()) {
			List<Marcas> marcas = marcasService.getAllMarcas();
			List<Procedencias> procedencias = procedenciasService.getAllProcedencias();
			List<TipoImpuesto> tipoImpuesto = tipoImpuestoService.getAllTipoImpuesto();
			model.addAttribute("mercaderia", mercaderia.get());
			model.addAttribute("listadoMarcas", marcas);
			model.addAttribute("listadoProcedencias", procedencias);
			model.addAttribute("listadoTipoImpuesto", tipoImpuesto);
			return "mercaderias/formulario";
		}

		return "redirect:/mercaderias";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		mercaderiasService.deleteMercaderia(id);
		return "redirect:/mercaderias";
	}
	
    @GetMapping("/api/mercaderias")
    @ResponseBody
    public List<Mercaderias> obtenerMercaderias() {
        return mercaderiasService.getAllMercaderias();
    }
}

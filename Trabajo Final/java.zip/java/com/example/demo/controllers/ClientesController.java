package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.Barrios;
import com.example.demo.models.Clientes;
import com.example.demo.services.ClientesService;
import com.example.demo.services.BarriosService;

import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/clientes")
@AllArgsConstructor
public class ClientesController {
	
	@Autowired
	private ClientesService clientesService;
	
	@Autowired
	private BarriosService barriosService;
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("clientes", clientesService.getAllClientes());
		return "clientes/listar";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		List<Barrios> barrios = barriosService.getAllBarrios();
		model.addAttribute("cliente", new Clientes());
		model.addAttribute("listadoBarrios", barrios);
		return "clientes/formulario";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Clientes cliente) {
		clientesService.saveCliente(cliente);
		return "redirect:/clientes";
	}
	
	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Clientes> cliente = clientesService.getClienteById(id);

		if (cliente.isPresent()) {
			List<Barrios> barrios = barriosService.getAllBarrios();
			model.addAttribute("cliente", cliente.get());
			model.addAttribute("listadoBarrios", barrios);
			return "clientes/formulario";
		}

		return "redirect:/clientes";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		clientesService.deleteCliente(id);
		return "redirect:/clientes";
	}
}

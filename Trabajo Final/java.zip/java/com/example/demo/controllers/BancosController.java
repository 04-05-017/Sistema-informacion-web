package com.example.demo.controllers;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.Bancos;
import com.example.demo.services.BancosService;
import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/bancos")
@AllArgsConstructor
public class BancosController {
	
	@Autowired
	private BancosService bancosService;
	
	@GetMapping
	public String listar(Model model) {
		model.addAttribute("bancos", bancosService.getAllBancos());
		return "bancos/listar";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("banco", new Bancos());
		return "bancos/formulario";
	}
	
	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Bancos banco) {
		bancosService.saveBanco(banco);
		return "redirect:/bancos";
	}
	
	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Bancos> banco = bancosService.getBancoById(id);

		if (banco.isPresent()) {
			model.addAttribute("banco", banco.get());
			return "bancos/formulario";
		}

		return "redirect:/bancos";
	}
	
	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		bancosService.deleteBanco(id);
		return "redirect:/bancos";
	}
}

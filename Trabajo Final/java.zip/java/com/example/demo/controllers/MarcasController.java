package com.example.demo.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.Marcas;
import com.example.demo.services.MarcasService;
import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/marcas")
@AllArgsConstructor
public class MarcasController {

	@Autowired
	private MarcasService marcasService;

	@GetMapping
	public String listar(Model model) {
		model.addAttribute("marcas", marcasService.getAllMarcas());
		return "marcas/listar";
	}

	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("marca", new Marcas());
		return "marcas/formulario";
	}

	@PostMapping("/guardar")
	public String guardar(@ModelAttribute Marcas marca) {
		marcasService.saveMarca(marca);
		return "redirect:/marcas";
	}

	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {

		Optional<Marcas> marca = marcasService.getMarcaById(id);

		if (marca.isPresent()) {
			model.addAttribute("marca", marca.get());
			return "marcas/formulario";
		}

		return "redirect:/paises";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		marcasService.deleteMarca(id);
		return "redirect:/marcas";
	}
}

package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.models.EstadoCivil;
import lombok.AllArgsConstructor;

@Controller
@RequestMapping(value = "/estado_civil")
@AllArgsConstructor
public class EstadoCivilController {

	//@Autowired
	//private EstadoCivilService estadoCivilService;

	
	@GetMapping
	public String listar(Model model) {
		//model.addAttribute("estado_civil", estadoCivilService.getAllEstadosCiviles());
		return "estado_civil/listar";
	}

	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("estado_civil", new EstadoCivil());
		return "estado_civil/formulario";
	}

	@PostMapping("/guardar")
	public String guardar(@ModelAttribute EstadoCivil estado_civil) {
		//estadoCivilService.saveEstadoCivil(estado_civil);
		return "redirect:/estado_civil";
	}

	@GetMapping("/editar/{id}")
	public String editar(@PathVariable Long id, Model model) {
		//Optional<EstadoCivil> estado_civil = estadoCivilService.getEstadoCivilById(id);
		//if (estado_civil.isPresent()) {
		//	model.addAttribute("estado_civil", estado_civil.get());
		//	return "estado_civil/formulario";
		//}
		return "redirect:/estado_civil";
	}

	@PostMapping("/eliminar")
	public String eliminar(@RequestParam Long id) {
		//estadoCivilService.deleteEstadoCivil(id);
		return "redirect:/estado_civil";
	}
}
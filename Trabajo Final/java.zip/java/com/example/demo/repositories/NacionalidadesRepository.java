package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Nacionalidades;


@Repository
public interface NacionalidadesRepository extends CrudRepository<Nacionalidades, Long> {

	@Query("SELECT n from Nacionalidades n")
	List<Nacionalidades> findByAll();
}

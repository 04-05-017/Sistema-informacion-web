package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.demo.models.Timbrados;

@Repository
public interface TimbradosRepository extends CrudRepository<Timbrados, Long> {
	
	@Query("SELECT t from Timbrados t")
	List<Timbrados> findByAll();
	
}

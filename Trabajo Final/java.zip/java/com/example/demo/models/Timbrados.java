package com.example.demo.models;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Table(name = "timbrados")
@Data
public class Timbrados {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_timbrado")
	private Long id;
	
	@Size(max = 4)
	@Column(name = "nro_desde")
	private Integer nroDesde;
	
	@Size(max = 4)
	@Column(name = "nro_hasta")
	private Integer nroHasta;
	
	@Size(max = 4)
	private Integer nro1;
	
	@Size(max = 4)
	private Integer nro2;
	
	@Size(max = 4)
	private Integer nro3;

	@Size(max = 4)
	@Column(name = "nro_timbrado")
	private Integer nroTimbrado;
	
    @NotNull
    @Column(name = "fecha_inicio")
    private LocalDate fechaInicio;
	
    @NotNull
    @Column(name = "fecha_fin")
    private LocalDate fechaFin;

    @ManyToOne
    @JoinColumn(name = "id_tipo_documento")
    @NotNull
    private TipoDocumentos tipoDocumento;
    
    @NotNull
    @Column(name = "estado")
    private String estado;    
    
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public LocalDate getFechaFin() {
		return fechaFin;
	}
	
	public LocalDate getFechaInicio() {
		return fechaInicio;
	}
	
	public Integer getNro1() {
		return nro1;
	}
	
	public Integer getNro2() {
		return nro2;
	}
	
	public Integer getNro3() {
		return nro3;
	}
	
	public Integer getNroDesde() {
		return nroDesde;
	}
	
	public Integer getNroHasta() {
		return nroHasta;
	}
	
	public Integer getNroTimbrado() {
		return nroTimbrado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setFechaFin(LocalDate fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	public void setFechaInicio(LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public void setNro1(Integer nro1) {
		this.nro1 = nro1;
	}
	
	public void setNro2(Integer nro2) {
		this.nro2 = nro2;
	}
	
	public void setNro3(Integer nro3) {
		this.nro3 = nro3;
	}
	
	public void setNroDesde(Integer nroDesde) {
		this.nroDesde = nroDesde;
	}
	
	public void setNroHasta(Integer nroHasta) {
		this.nroHasta = nroHasta;
	}
	
	public void setNroTimbrado(Integer nroTimbrado) {
		this.nroTimbrado = nroTimbrado;
	}
	
	public TipoDocumentos getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(TipoDocumentos tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}
package com.example.demo.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Table(name = "nacionalidades")
@Data
public class Nacionalidades {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_nacionalidad")
    private Long id;

    @NotNull
    @Size(max = 80)
    @Column(length = 80, unique = true)
    private String descripcion;
    
    public String getDescripcion() {
		return descripcion;
	}
    
    public Long getId() {
		return id;
	}
    
    public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
    
    public void setId(Long id) {
		this.id = id;
	}
}

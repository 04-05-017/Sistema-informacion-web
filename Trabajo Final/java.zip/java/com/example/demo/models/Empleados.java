package com.example.demo.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "empleados")
@Data
public class Empleados {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_empleado")
    private Long id;

    @NotNull
    @Size(max = 15)
    @Column(length = 15)
    private String legajo;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "id_barrio")
    private Barrios barrio;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "id_nacionalidad")
    private Nacionalidades nacionalidad;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuarios usuario;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "id_estado_civil")
    private EstadoCivil estadoCivil;

    @NotNull
    @Size(max = 50)
    @Column(length = 50)
    private String nombres;

    @NotNull
    @Size(max = 50)
    @Column(length = 50)
    private String apellidos;

    @NotNull
    @Size(max = 20)
    @Column(name = "cedula_identidad", length = 20)
    private String cedulaIdentidad;

    @NotNull
    @Column(name = "fecha_nac")
    private LocalDate fechaNacimiento;

    @Column(length = 1)
    private String sexo;

    @Column(length = 1)
    private String estado;

    @Column(name = "fecha_incorporacion")
    private LocalDate fechaIncorporacion;

    @NotNull
    @Size(max = 100)
    @Column(length = 100)
    private String direccion;

    @NotNull
    @Size(max = 20)
    @Column(length = 20)
    private String telefono;

    @NotNull
    @Size(max = 50)
    @Column(length = 50)
    private String email;
    
    public void setUsuario(Usuarios usuario) {
		this.usuario = usuario;
	}
    
    public String getApellidos() {
		return apellidos;
	}
    
    public Barrios getBarrio() {
		return barrio;
	}
    
    public String getCedulaIdentidad() {
		return cedulaIdentidad;
	}
    
    public String getDireccion() {
		return direccion;
	}
    
    public String getEmail() {
		return email;
	}
    
    public String getEstado() {
		return estado;
	}
    
    public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}
    
    public LocalDate getFechaIncorporacion() {
		return fechaIncorporacion;
	}
    
    public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
    
    public Long getId() {
		return id;
	}
    
    public String getLegajo() {
		return legajo;
	}
    
    public Nacionalidades getNacionalidad() {
		return nacionalidad;
	}
    
    public String getNombres() {
		return nombres;
	}
    
    public String getSexo() {
		return sexo;
	}
    
    public String getTelefono() {
		return telefono;
	}
    
    public Usuarios getUsuario() {
		return usuario;
	}
    
    public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
    
    public void setBarrio(Barrios barrio) {
		this.barrio = barrio;
	}
    
    public void setCedulaIdentidad(String cedulaIdentidad) {
		this.cedulaIdentidad = cedulaIdentidad;
	}
    
    public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
    
    public void setEmail(String email) {
		this.email = email;
	}
    
    public void setEstado(String estado) {
		this.estado = estado;
	}
    
    public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}
    
    public void setFechaIncorporacion(LocalDate fechaIncorporacion) {
		this.fechaIncorporacion = fechaIncorporacion;
	}
    
    public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
    
    public void setId(Long id) {
		this.id = id;
	}
    
    public void setLegajo(String legajo) {
		this.legajo = legajo;
	}
    
    public void setNacionalidad(Nacionalidades nacionalidad) {
		this.nacionalidad = nacionalidad;
	}
    
    public void setNombres(String nombres) {
		this.nombres = nombres;
	}
    
    public void setSexo(String sexo) {
		this.sexo = sexo;
	}
    
    public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
}

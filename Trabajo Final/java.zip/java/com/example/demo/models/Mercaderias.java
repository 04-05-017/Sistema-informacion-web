package com.example.demo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Table(name = "mercaderias")
@Data
public class Mercaderias {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_mercaderia")
	private Long id;
	
    @ManyToOne
    @JoinColumn(name = "id_marca")
    @NotNull
    private Marcas marca;
	
    @ManyToOne
    @JoinColumn(name = "id_tipo_impuesto")
    @NotNull
    private TipoImpuesto tipoImpuesto;
    
    @ManyToOne
    @JoinColumn(name = "id_procedencia")
    @NotNull
    private Procedencias procedencia; 
    
    @Column(name = "descripcion", length = 100)
    @NotNull
    private String descripcion;
    
    @Column(name = "afecta_existencia", length = 1)
    @NotNull
    private String afectaExistencia; //-- "S" o "N"

    @Column(name = "precio_compra", precision = 12, scale = 0)
    @NotNull
    private java.math.BigDecimal precioCompra;

    @Column(name = "precio_venta", precision = 12, scale = 0)
    @NotNull
    private java.math.BigDecimal precioVenta;    
    
    public String getAfectaExistencia() {
		return afectaExistencia;
	}
    
    public String getDescripcion() {
		return descripcion;
	}
    
    public Long getId() {
		return id;
	}
    
    public Marcas getMarca() {
		return marca;
	}
    
    public java.math.BigDecimal getPrecioCompra() {
		return precioCompra;
	}
    
    public java.math.BigDecimal getPrecioVenta() {
		return precioVenta;
	}
    
    public Procedencias getProcedencia() {
		return procedencia;
	}
    
    public TipoImpuesto getTipoImpuesto() {
		return tipoImpuesto;
	}
    
    public void setAfectaExistencia(String afectaExistencia) {
		this.afectaExistencia = afectaExistencia;
	}
    
    public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
    
    public void setId(Long id) {
		this.id = id;
	}
    
    public void setMarca(Marcas marca) {
		this.marca = marca;
	}
    
    public void setPrecioCompra(java.math.BigDecimal precioCompra) {
		this.precioCompra = precioCompra;
	}
    
    public void setPrecioVenta(java.math.BigDecimal precioVenta) {
		this.precioVenta = precioVenta;
	}
    
    public void setProcedencia(Procedencias procedencia) {
		this.procedencia = procedencia;
	}
    
    public void setTipoImpuesto(TipoImpuesto tipoImpuesto) {
		this.tipoImpuesto = tipoImpuesto;
	}
}
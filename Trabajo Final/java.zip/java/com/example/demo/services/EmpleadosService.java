package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Empleados;

public interface EmpleadosService {

	List<Empleados> getAllEmpleados();

	Optional<Empleados> getEmpleadoById(Long id);

	void saveEmpleado(Empleados empleado);

	void deleteEmpleado(Long id);
}

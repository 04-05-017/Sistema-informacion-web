package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Bancos;

public interface BancosService {

	List<Bancos> getAllBancos();

	Optional<Bancos> getBancoById(Long id);

	void saveBanco(Bancos pais);

	void deleteBanco(Long id);
}

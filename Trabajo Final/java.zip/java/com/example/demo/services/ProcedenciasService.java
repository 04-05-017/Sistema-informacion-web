package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Procedencias;

public interface ProcedenciasService {

	List<Procedencias> getAllProcedencias();

	Optional<Procedencias> getProcedenciaById(Long id);

	void saveProcedencia(Procedencias pais);

	void deleteProcedencia(Long id);
}

package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Procedencias;
import com.example.demo.repositories.ProcedenciasRepository;
import com.example.demo.services.ProcedenciasService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ProcedenciasServiceImpl implements ProcedenciasService {
	
	@Autowired
	private ProcedenciasRepository procedenciasRepository;
	
	@Override
	public List<Procedencias> getAllProcedencias() {
		return this.procedenciasRepository.findByAll();
	}
	
	@Override
	public Optional<Procedencias> getProcedenciaById(Long id) {
		return this.procedenciasRepository.findById(id);
	}
	
	@Override
	public void saveProcedencia(Procedencias procedencia) {
		if (Objects.nonNull(procedencia)) {
			this.procedenciasRepository.save(procedencia);
		}
	}
	
	@Override
	public void deleteProcedencia(Long id) {
		if(Objects.nonNull(id)) {
			this.procedenciasRepository.findById(id).ifPresent(procedencia -> this.procedenciasRepository.delete(procedencia));
		}
	}

}

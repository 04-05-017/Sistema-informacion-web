package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Barrios;
import com.example.demo.repositories.BarriosRepository;
import com.example.demo.services.BarriosService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BarriosServiceImpl implements BarriosService {
	
	@Autowired
	private BarriosRepository barriosRepository;

	@Override
	public List<Barrios> getAllBarrios() {
		return this.barriosRepository.findByAll();
	}

	@Override
	public Optional<Barrios> getBarrioById(Long id) {
		return this.barriosRepository.findById(id);
	}

	@Override
	public void saveBarrio(Barrios barrio) {
		if (Objects.nonNull(barrio)) {
			this.barriosRepository.save(barrio);
		}
	}

	@Override
	public void deleteBarrio(Long id) {
		if(Objects.nonNull(id)) {
			this.barriosRepository.findById(id).ifPresent(barrio -> this.barriosRepository.delete(barrio));
		}
	}
}
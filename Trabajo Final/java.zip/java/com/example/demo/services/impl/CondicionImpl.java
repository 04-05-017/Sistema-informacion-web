package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Condicion;
import com.example.demo.repositories.CondicionRepository;
import com.example.demo.services.CondicionService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CondicionImpl implements CondicionService {
	
	@Autowired
	private CondicionRepository condicionRepository;

	@Override
	public List<Condicion> getAllCondicion() {
		return this.condicionRepository.findByAll();
	}

	@Override
	public Optional<Condicion> getCondicionById(Long id) {
		return this.condicionRepository.findById(id);
	}

	@Override
	public void saveCondicion(Condicion condicion) {
		if (Objects.nonNull(condicion)) {
			this.condicionRepository.save(condicion);
		}
	}

	@Override
	public void deleteCondicion(Long id) {
		if(Objects.nonNull(id)) {
			this.condicionRepository.findById(id).ifPresent(condicion -> this.condicionRepository.delete(condicion));
		}
	}

}

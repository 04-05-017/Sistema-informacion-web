package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.EstadoCivil;
import com.example.demo.repositories.EstadoCivilRepository;
import com.example.demo.services.EstadoCivilService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class EstadoCivilServiceImpl implements EstadoCivilService {
	
	@Autowired
	private EstadoCivilRepository estadoCivilRepository;

	@Override
	public List<EstadoCivil> getAllEstadosCiviles() {
		return this.estadoCivilRepository.findByAll();
	}

	@Override
	public Optional<EstadoCivil> getEstadoCivilById(Long id) {
		return this.estadoCivilRepository.findById(id);
	}

	@Override
	public void saveEstadoCivil(EstadoCivil estadoCivil) {
		if (Objects.nonNull(estadoCivil)) {
			this.estadoCivilRepository.save(estadoCivil);
		}
	}

	@Override
	public void deleteEstadoCivil(Long id) {
		if(Objects.nonNull(id)) {
			this.estadoCivilRepository.findById(id).ifPresent(estadoCivil -> this.estadoCivilRepository.delete(estadoCivil));
		}
	}
}
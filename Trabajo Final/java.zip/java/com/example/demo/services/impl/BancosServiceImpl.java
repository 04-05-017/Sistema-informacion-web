package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Bancos;
import com.example.demo.repositories.BancosRepository;
import com.example.demo.services.BancosService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BancosServiceImpl implements BancosService {
	
	@Autowired
	private BancosRepository bancosRepository;

	@Override
	public List<Bancos> getAllBancos() {
		return this.bancosRepository.findByAll();
	}

	@Override
	public Optional<Bancos> getBancoById(Long id) {
		return this.bancosRepository.findById(id);
	}

	@Override
	public void saveBanco(Bancos banco) {
		if (Objects.nonNull(banco)) {
			this.bancosRepository.save(banco);
		}
	}

	@Override
	public void deleteBanco(Long id) {
		if(Objects.nonNull(id)) {
			this.bancosRepository.findById(id).ifPresent(banco -> this.bancosRepository.delete(banco));
		}
	}
}

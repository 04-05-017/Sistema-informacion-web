package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Nacionalidades;
import com.example.demo.repositories.NacionalidadesRepository;
import com.example.demo.services.NacionalidadesService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class NacionalidadesServiceImpl implements NacionalidadesService {
	
	@Autowired
	private NacionalidadesRepository nacionalidadesRepository;

	@Override
	public List<Nacionalidades> getAllNacionalidades() {
		return this.nacionalidadesRepository.findByAll();
	}

	@Override
	public Optional<Nacionalidades> getNacionalidadById(Long id) {
		return this.nacionalidadesRepository.findById(id);
	}

	@Override
	public void saveNacionalidad(Nacionalidades nacionalidad) {
		if (Objects.nonNull(nacionalidad)) {
			this.nacionalidadesRepository.save(nacionalidad);
		}
	}

	@Override
	public void deleteNacionalidad(Long id) {
		if(Objects.nonNull(id)) {
			this.nacionalidadesRepository.findById(id).ifPresent(nacionalidad -> this.nacionalidadesRepository.delete(nacionalidad));
		}
	}
}
package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Marcas;
import com.example.demo.repositories.MarcasRepository;
import com.example.demo.services.MarcasService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class MarcasServiceImpl implements MarcasService {
	
	@Autowired
	private MarcasRepository marcasRepository;

	@Override
	public List<Marcas> getAllMarcas() {
		return this.marcasRepository.findByAll();
	}

	@Override
	public Optional<Marcas> getMarcaById(Long id) {
		return this.marcasRepository.findById(id);
	}

	@Override
	public void saveMarca(Marcas marca) {
		if (Objects.nonNull(marca)) {
			this.marcasRepository.save(marca);
		}
	}

	@Override
	public void deleteMarca(Long id) {
		if(Objects.nonNull(id)) {
			this.marcasRepository.findById(id).ifPresent(marca -> this.marcasRepository.delete(marca));
		}
	}

}

package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Timbrados;
import com.example.demo.repositories.TimbradosRepository;
import com.example.demo.services.TimbradosService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class TimbradosServiceImpl implements TimbradosService {
	
	@Autowired
	private TimbradosRepository timbradosRepository;

	@Override
	public List<Timbrados> getAllTimbrados() {
		return this.timbradosRepository.findByAll();
	}
	
	@Override
	public Optional<Timbrados> getTimbradoById(Long id) {
		return this.timbradosRepository.findById(id);
	}
	
	@Override
	public void saveTimbrado(Timbrados timbrado) {
		if (Objects.nonNull(timbrado)) {
			this.timbradosRepository.save(timbrado);
		}
	}
	
	@Override
	public void deleteTimbrado(Long id) {
		if(Objects.nonNull(id)) {
			this.timbradosRepository.findById(id).ifPresent(timbrado -> this.timbradosRepository.delete(timbrado));
		}
	}
}
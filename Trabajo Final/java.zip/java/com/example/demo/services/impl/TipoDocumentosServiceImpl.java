package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.TipoDocumentos;
import com.example.demo.repositories.TipoDocumentosRepository;
import com.example.demo.services.TipoDocumentosService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class TipoDocumentosServiceImpl implements TipoDocumentosService {
	
	@Autowired
	private TipoDocumentosRepository tipoDocumentosRepository;

	@Override
	public List<TipoDocumentos> getAllTipoDocumentos() {
		return this.tipoDocumentosRepository.findByAll();
	}

	@Override
	public Optional<TipoDocumentos> getTipoDocumentoById(Long id) {
		return this.tipoDocumentosRepository.findById(id);
	}

	@Override
	public void saveTipoDocumento(TipoDocumentos tipoDocumento) {
		if (Objects.nonNull(tipoDocumento)) {
			this.tipoDocumentosRepository.save(tipoDocumento);
		}
	}

	@Override
	public void deleteTipoDocumento(Long id) {
		if(Objects.nonNull(id)) {
			this.tipoDocumentosRepository.findById(id).ifPresent(tipoDocumentos -> this.tipoDocumentosRepository.delete(tipoDocumentos));
		}
	}

}

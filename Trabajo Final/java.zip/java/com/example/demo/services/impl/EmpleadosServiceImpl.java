package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Empleados;
import com.example.demo.repositories.EmpleadosRepository;
import com.example.demo.services.EmpleadosService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class EmpleadosServiceImpl implements EmpleadosService {
	
	@Autowired
	private EmpleadosRepository empleadosRepository;

	@Override
	public List<Empleados> getAllEmpleados() {
		return this.empleadosRepository.findByAll();
	}

	@Override
	public Optional<Empleados> getEmpleadoById(Long id) {
		return this.empleadosRepository.findById(id);
	}

	@Override
	public void saveEmpleado(Empleados empleado) {
		if (Objects.nonNull(empleado)) {
			this.empleadosRepository.save(empleado);
		}
	}

	@Override
	public void deleteEmpleado(Long id) {
		if(Objects.nonNull(id)) {
			this.empleadosRepository.findById(id).ifPresent(empleado -> this.empleadosRepository.delete(empleado));
		}
	}
}
package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Clientes;
import com.example.demo.repositories.ClientesRepository;
import com.example.demo.services.ClientesService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ClientesServiceImpl implements ClientesService {
	
	@Autowired
	private ClientesRepository clientesRepository;

	@Override
	public List<Clientes> getAllClientes() {
		return this.clientesRepository.findByAll();
	}

	@Override
	public Optional<Clientes> getClienteById(Long id) {
		return this.clientesRepository.findById(id);
	}

	@Override
	public void saveCliente(Clientes cliente) {
		if (Objects.nonNull(cliente)) {
			this.clientesRepository.save(cliente);
		}
	}

	@Override
	public void deleteCliente(Long id) {
		if(Objects.nonNull(id)) {
			this.clientesRepository.findById(id).ifPresent(cliente -> this.clientesRepository.delete(cliente));
		}
	}
}
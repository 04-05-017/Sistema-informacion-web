package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Cajas;
import com.example.demo.repositories.CajasRepository;
import com.example.demo.services.CajasService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CajasServiceImpl implements CajasService {
	
	@Autowired
	private CajasRepository cajasRepository;

	@Override
	public List<Cajas> getAllCajas() {
		return this.cajasRepository.findByAll();
	}

	@Override
	public Optional<Cajas> getCajaById(Long id) {
		return this.cajasRepository.findById(id);
	}

	@Override
	public void saveCaja(Cajas caja) {
		if (Objects.nonNull(caja)) {
			this.cajasRepository.save(caja);
		}
	}

	@Override
	public void deleteCaja(Long id) {
		if(Objects.nonNull(id)) {
			this.cajasRepository.findById(id).ifPresent(caja -> this.cajasRepository.delete(caja));
		}
	}

}

package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Proveedores;
import com.example.demo.repositories.ProveedoresRepository;
import com.example.demo.services.ProveedoresService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ProveedoresServiceImpl implements ProveedoresService {
	
	@Autowired
	private ProveedoresRepository proveedoresRepository;

	@Override
	public List<Proveedores> getAllProveedores() {
		return this.proveedoresRepository.findByAll();
	}

	@Override
	public Optional<Proveedores> getProveedorById(Long id) {
		return this.proveedoresRepository.findById(id);
	}

	@Override
	public void saveProveedor(Proveedores barrio) {
		if (Objects.nonNull(barrio)) {
			this.proveedoresRepository.save(barrio);
		}
	}

	@Override
	public void deleteProveedor(Long id) {
		if(Objects.nonNull(id)) {
			this.proveedoresRepository.findById(id).ifPresent(proveedor -> this.proveedoresRepository.delete(proveedor));
		}
	}
}
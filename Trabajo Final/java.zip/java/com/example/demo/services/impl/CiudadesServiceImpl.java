package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.models.Ciudades;
import com.example.demo.repositories.CiudadesRepository;
import com.example.demo.services.CiudadesService;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CiudadesServiceImpl implements CiudadesService {
	
	@Autowired
	private CiudadesRepository ciudadesRepository;

	@Override
	public List<Ciudades> getAllCiudades() {
		return this.ciudadesRepository.findByAll();
	}

	@Override
	public Optional<Ciudades> getCiudadById(Long id) {
		return this.ciudadesRepository.findById(id);
	}

	@Override
	public void saveCiudad(Ciudades ciudad) {
		if (Objects.nonNull(ciudad)) {
			this.ciudadesRepository.save(ciudad);
		}
	}

	@Override
	public void deleteCiudad(Long id) {
		if(Objects.nonNull(id)) {
			this.ciudadesRepository.findById(id).ifPresent(pais -> this.ciudadesRepository.delete(pais));
		}
	}
}
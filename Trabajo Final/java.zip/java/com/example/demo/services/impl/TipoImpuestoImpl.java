package com.example.demo.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.TipoImpuesto;
import com.example.demo.repositories.TipoImpuestoRepository;
import com.example.demo.services.TipoImpuestoService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class TipoImpuestoImpl implements TipoImpuestoService {
	
	@Autowired
	private TipoImpuestoRepository tipoImpuestoRepository;

	@Override
	public List<TipoImpuesto> getAllTipoImpuesto() {
		return this.tipoImpuestoRepository.findByAll();
	}

	@Override
	public Optional<TipoImpuesto> getTipoImpuestoById(Long id) {
		return this.tipoImpuestoRepository.findById(id);
	}

	@Override
	public void saveTipoImpuesto(TipoImpuesto tipoImpuesto) {
		if (Objects.nonNull(tipoImpuesto)) {
			this.tipoImpuestoRepository.save(tipoImpuesto);
		}
	}

	@Override
	public void deleteTipoImpuesto(Long id) {
		if(Objects.nonNull(id)) {
			this.tipoImpuestoRepository.findById(id).ifPresent(tipoImpuesto -> this.tipoImpuestoRepository.delete(tipoImpuesto));
		}
	}

}

package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import com.example.demo.models.TipoDocumentos;

public interface TipoDocumentosService {

	List<TipoDocumentos> getAllTipoDocumentos();

	Optional<TipoDocumentos> getTipoDocumentoById(Long id);

	void saveTipoDocumento(TipoDocumentos tipoDocumentos);

	void deleteTipoDocumento(Long id);
}

package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Cajas;

public interface CajasService {

	List<Cajas> getAllCajas();

	Optional<Cajas> getCajaById(Long id);

	void saveCaja(Cajas pais);

	void deleteCaja(Long id);
}

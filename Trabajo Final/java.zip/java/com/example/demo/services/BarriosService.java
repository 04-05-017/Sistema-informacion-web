package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Barrios;

public interface BarriosService {

	List<Barrios> getAllBarrios();

	Optional<Barrios> getBarrioById(Long id);

	void saveBarrio(Barrios ciudad);

	void deleteBarrio(Long id);
}

package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Nacionalidades;

public interface NacionalidadesService {

	List<Nacionalidades> getAllNacionalidades();

	Optional<Nacionalidades> getNacionalidadById(Long id);

	void saveNacionalidad(Nacionalidades pais);

	void deleteNacionalidad(Long id);
}

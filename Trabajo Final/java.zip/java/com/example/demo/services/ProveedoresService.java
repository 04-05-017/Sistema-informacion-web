package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Proveedores;

public interface ProveedoresService {
	
	List<Proveedores> getAllProveedores();
	
	Optional<Proveedores> getProveedorById(Long id);
	
	void saveProveedor(Proveedores proveedores);
	
	void deleteProveedor(Long id);
	
}

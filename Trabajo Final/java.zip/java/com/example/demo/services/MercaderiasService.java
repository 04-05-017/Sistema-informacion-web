package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Mercaderias;

public interface MercaderiasService {

	List<Mercaderias> getAllMercaderias();

	Optional<Mercaderias> getMercaderiaById(Long id);

	void saveMercaderia(Mercaderias ciudad);

	void deleteMercaderia(Long id);
}

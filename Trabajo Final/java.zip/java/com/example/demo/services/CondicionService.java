package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import com.example.demo.models.Condicion;

public interface CondicionService {

	List<Condicion> getAllCondicion();

	Optional<Condicion> getCondicionById(Long id);

	void saveCondicion(Condicion pais);

	void deleteCondicion(Long id);
}

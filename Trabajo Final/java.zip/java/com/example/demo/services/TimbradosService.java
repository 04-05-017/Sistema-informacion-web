package com.example.demo.services;

import java.util.List;
import java.util.Optional;
import com.example.demo.models.Timbrados;

public interface TimbradosService {

	List<Timbrados> getAllTimbrados();

	Optional<Timbrados> getTimbradoById(Long id);

	void saveTimbrado(Timbrados timbrado);

	void deleteTimbrado(Long id);
}

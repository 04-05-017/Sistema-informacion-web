package com.example.demo.dto;

import lombok.Data;

@Data
public class VentaDTO {
    private String fecha;
    private String cliente;
    private String tipoDocumento;
    private String productosJson;  // JSON que luego vas a parsear en Java
    
    public VentaDTO() {
		// TODO Auto-generated constructor stub
	}
    
    public String getCliente() {
		return cliente;
	}
    
    public String getFecha() {
		return fecha;
	}
    
    public String getProductosJson() {
		return productosJson;
	}
    
    public String getTipoDocumento() {
		return tipoDocumento;
	}
    
    public void setCliente(String cliente) {
		this.cliente = cliente;
	}
    
    public void setFecha(String fecha) {
		this.fecha = fecha;
	}
    
    public void setProductosJson(String productosJson) {
		this.productosJson = productosJson;
	}
    
    public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}
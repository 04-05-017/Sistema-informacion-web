package com.example.demo.dto;

public class Producto {
    private String descripcion;
    private String presentacion;
    private double precio;
    private int cantidad;
    
    public Producto() {
		// TODO Auto-generated constructor stub
	}
    
    // Getters y setters
    public int getCantidad() {
		return cantidad;
	}
    
    public String getDescripcion() {
		return descripcion;
	}
    
    public double getPrecio() {
		return precio;
	}
    
    public String getPresentacion() {
		return presentacion;
	}
    
    public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
    
    public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
    
    public void setPrecio(double precio) {
		this.precio = precio;
	}
    
    public void setPresentacion(String presentacion) {
		this.presentacion = presentacion;
	}
}

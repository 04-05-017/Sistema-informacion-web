package com.example.demo.dto;

import java.util.List;

public class Venta {
    private String fecha;
    private String cliente;
    private String tipoDocumento;
    private List<Producto> productos; // Lista de productos relacionados con la venta
    
    public Venta() {
		// TODO Auto-generated constructor stub
	}
    
    // Getters y setters
    public String getCliente() {
		return cliente;
	}
    
    public String getFecha() {
		return fecha;
	}
    
    public List<Producto> getProductos() {
		return productos;
	}
    
    public String getTipoDocumento() {
		return tipoDocumento;
	}
    
    public void setCliente(String cliente) {
		this.cliente = cliente;
	}
    
    public void setFecha(String fecha) {
		this.fecha = fecha;
	}
    
    public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}
    
    public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}
